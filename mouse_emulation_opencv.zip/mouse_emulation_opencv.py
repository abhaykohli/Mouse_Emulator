import cv2
import numpy as np
from pynput.mouse import Button, Controller
import wx

# initialize global variable as pynput.mouse.Controller
mouse = Controller()

# determine screen resolution
app = wx.App(False)  # initialize app
(screenx, screeny) = wx.GetDisplaySize()  # fetch screen coordinates

# initialize webcam
(camx, camy) = (320, 240)  # specify capture resolution
cap = cv2.VideoCapture(0)  # initialize webcam (0 = internal webcam)
cap.set(3, camx)  # set capture width
cap.set(4, camy)  # set capture height

# specify upper and lower bounds for color being detected (green)
# format: hsv (hue saturation value)
lower_green = np.array([33,60,30])
upper_green = np.array([102,255,255])

# define kernels
kernel_opening = np.ones((5,5))  # opening kernel
kernel_closing = np.ones((20,20))  # closing kernel

# remember previous mouse location to smoothen mouse position transition
mouse_loc_old = np.array([0,0])
mouse_loc = np.array([0,0])

# specify a dampening factor (must be >1) to smoothen mouse position transition
damping_factor = 2 #Damping factor must be greater than 1

# remember mouse pressed state
is_pressed = 0

# remember size of rectangle bounding the two detected objects (helps to prevent clicking action when only one object is present on the screen)
openx,openy,openw,openh = (0,0,0,0)


while True:
    ret, img = cap.read()  # capture feed
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # convert color scheme from RGB to HSV
    mask = cv2.inRange(imgHSV, lower_green, upper_green)  # apply color detection filters

    # reduce noise using morphology
    mask_after_open_morph = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel_opening)
    mask_after_close_morph = cv2.morphologyEx(mask_after_open_morph, cv2.MORPH_CLOSE, kernel_closing)
    final_mask = mask_after_close_morph

    # get detected objects
    conts, h = cv2.findContours(final_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    # if two green objects are detected (fingers are apart)
    if len(conts) == 2:
        # if mouse left button is pressed, release it
        if is_pressed == 1:
            is_pressed = 0
            mouse.release(Button.left)

        # drawing bounding rectable around both green objects
        x1,y1,w1,h1 = cv2.boundingRect(conts[0])  # get coordinates and size of first object
        x2,y2,w2,h2 = cv2.boundingRect(conts[1])  # get coordinates and size of second object

        # draw blue (255,0,0) rectangles of above sizes (thickness = 2)
        cv2.rectangle(img, (x1,y1), (x1+w1,y1+h1), (255,0,0), 2)
        cv2.rectangle(img, (x2,y2), (x2+w2,y2+h2), (255,0,0), 2)

        # draw a line between the two rectangles
        cx1 = int(x1 + w1/2)  # centreX of rect1
        cy1 = int(y1 + h1/2)  # centreY of rect1
        cx2 = int(x2 + w2/2)  # centreX of rect2
        cy2 = int(y2 + h2/2)  # centreY of rect2
        cv2.line(img, (cx1,cy1), (cx2,cy2), (255,0,0), 2)  # draw blue line between centres (thickness = 2)

        # determine mouse reference point (centre of above line)
        clx = int((cx1+cx2)/2)  # centreX of line
        cly = int((cy1+cy2)/2)  # centreY of line
        cv2.circle(img, (clx,cly), 2, (0,0,255), 2)  # draw red circle on central point of radius = 2 (thickness = 2)

        # adding the damping factor so that the movement of the mouse is smoother
        mouse_loc = mouse_loc_old + ((clx,cly) - mouse_loc_old)/damping_factor
        # change actual mouse position programatically (xpos is subtracted from screenx to prevent lateral inversion)
        mouse.position = ( screenx - int( (mouse_loc[0]*screenx)/camx ), int( (mouse_loc[1]*screeny)/camy ) )
        # wait for mouse to be in position
        while mouse.position != ( screenx - int( (mouse_loc[0]*screenx)/camx ), int( (mouse_loc[1]*screeny)/camy ) ):
            pass
        # remember mouse location
        mouse_loc_old = mouse_loc
        # get size of rectangle that bounds both objects
        openx,openy,openw,openh = cv2.boundingRect(np.array([[ [x1,y1],[x1+w1,y1+h1],[x2,y2],[x2+w2,y2+h2] ]]))


    # if only one green object is detected (fingers are together)
    elif(len(conts)==1):
        x,y,w,h = cv2.boundingRect(conts[0])
        # we check first and we allow the press fct if it's not pressed yet
        # if mouse left button isn't already pressed (prevents continuous clicking)
        if is_pressed == 0:
            # if difference between bounding rectangle of detected objects put together and bounding rectangle of the two objects apart is not more than 30% (prevents clicking when only one object is present on screen)
            if abs((w*h - openw*openh)*100 / (w*h)) < 30:
                is_pressed = 1  # remember clicked state
                mouse.press(Button.left)  # press mouse left button programatically
                openx,openy,openw,openh = (0,0,0,0)  # update outer bounding rectangle

        # otherwise draw rectangle around one detected object (representing clicked state)
        else:
            x,y,w,h = cv2.boundingRect(conts[0])
            cv2.rectangle(img, (x,y), (x+w,y+h), (255,0,0), 2)

            # draw a red circle (= size of rectangle) to differentiate from rectangles drawn during non-clicked state
            cx = int(x + w/2)
            cy = int(y + h/2)
            cv2.circle(img, (cx,cy), int((w+h)/4), (0,0,255), 2)

            # update mouse location (same as previous logic)
            mouse_loc = mouse_loc_old + ((cx,cy) - mouse_loc_old)/damping_factor
            mouse.position = ( screenx - int( (mouse_loc[0]*screenx)/camx ),int( (mouse_loc[1]*screeny)/camy ) )
            while mouse.position != ( screenx - int( (mouse_loc[0]*screenx)/camx ),int( (mouse_loc[1]*screeny)/camy ) ):
                pass
            mouse_loc_old = mouse_loc

        
        
    # update display window 
    cv2.imshow("Virtual mouse", img)

    # wait for key press ("w" = exit) 
    if cv2.waitKey(1) & 0xFF==ord('w'):
        break

# release resources
cap.release()
cv2.destroyAllWindows()